# 2110446 Data Science Course at Chula 2022

![alt text](https://github.com/kaopanboonyuen/2110446_DataScience_2021s2/raw/main/%20files/welcome-to-the-dark-side-of-science-data-science.jpeg "join ds")

## Short links for exercises:

### Week8: Data Ingestion

![alt text](https://github.com/kaopanboonyuen/2110446_DataScience_2021s2/raw/main/files/week8_assignment.png "week8 data ingestion")